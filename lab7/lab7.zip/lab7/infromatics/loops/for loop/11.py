sum = 0
n = 0
n = int(input())
for i in range(0, n):
    x=int(input())
    sum+=x
print(sum)