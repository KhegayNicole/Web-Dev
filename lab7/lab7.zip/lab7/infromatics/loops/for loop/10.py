sum = 0
for i in range(0, 101):
    x=int(input())
    sum+=x
print(sum)