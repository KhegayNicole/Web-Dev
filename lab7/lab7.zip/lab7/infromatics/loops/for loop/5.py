a = input()
sum = 0
for i in a:
    sum+=int(i)
print(sum)
