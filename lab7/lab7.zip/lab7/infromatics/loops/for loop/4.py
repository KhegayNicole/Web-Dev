x = input()
d = int(input())
counter = 0
for i in x:
    if int(i)==d:
        counter+=1
print(counter)
