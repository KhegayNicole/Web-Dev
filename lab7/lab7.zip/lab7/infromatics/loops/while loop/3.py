N = int(input())
power_of_two = 1

while power_of_two <= N:
    print(power_of_two, end=' ')
    power_of_two *= 2
