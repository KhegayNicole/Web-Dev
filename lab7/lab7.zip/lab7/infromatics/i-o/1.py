from math import sqrt


a = int(input())
b = int(input())
print(sqrt(a**2+b**2))