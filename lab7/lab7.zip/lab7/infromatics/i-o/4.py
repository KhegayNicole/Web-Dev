from math import floor

a = int(input())
b = int(input())
print(b-floor(b/a)*a)
