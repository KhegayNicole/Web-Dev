def xor(x, y):
    return int(x) ^ int(y)

# Чтение входных данных
x, y = map(int, input().split())

# Вывод результата
print(xor(x, y))
