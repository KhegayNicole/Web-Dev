def power(a, n):
    return a ** n

# Чтение входных данных
a, n = map(float, input().split())

# Вывод результата
print(power(a, int(n)))
