def hello_name(name):
  return "Hello" + name
